# Vision College PWA - USSD Terminal Access Instructions

## 🎓 Welcome to Vision College USSD Interface

### 📱 How to Access USSD via Terminal

1. **Open Terminal/Command Prompt**
   - Windows: Press `Win + R`, type `cmd`, press Enter
   - Mac/Linux: Open Terminal application

2. **Navigate to the project directory**
   ```bash
   cd C:\Users\Tatenda\vision-college-pwa
   ```

3. **Run the USSD Terminal Interface**
   ```bash
   node terminal-ussd.js
   ```

### 🔐 Login Credentials

**USSD Passwords (works for both terminal and web interface):**
- **Student**: `password123`
- **Teacher**: `teacher123` 
- **Admin**: `admin123`

**Web Login Credentials (username/password):**
- **Student**: `student1` / `password123`
- **Teacher**: `teacher1` / `teacher123`
- **Admin**: `admin` / `admin123`

### 📋 How to Use USSD Interface

1. **Dial USSD Code**: Enter `*123#` when prompted
2. **Enter Password**: Use one of the passwords above
3. **Select Portal**: Choose Student Portal (1) or Teacher Portal (2)
4. **Navigate**: Follow the menu options displayed

### 🎯 Student Portal Features (Updated)

- **📊 View Term Results**: See overall performance summary with total scores, averages, and grades
- **🏆 View Subject Grades**: View detailed grades for each subject with teacher comments
- **👤 Student Profile**: View personal and academic information

### 👨‍🏫 Teacher Portal Features

- **📊 View All Student Results**: See all students' performance
- **🏆 Manage Grades**: Grade management system (under development)
- **👤 Teacher Profile**: View teacher information

### 🎨 Color Scheme Update

The system now uses a **green and white** color scheme as requested:
- Primary Green: `#4CAF50`
- Secondary Green: `#2E7D32`
- Accent Green: `#66BB6A`
- White backgrounds for content areas

### 📊 Student Data Available

**Student: Tatenda (Student ID: VC2024001)**
- **Mathematics**: 92/100 (A) - "Excellent performance in algebra and geometry"
- **Physics**: 85/100 (B+) - "Good understanding of mechanics and thermodynamics"
- **Chemistry**: 88/100 (A-) - "Strong performance in organic chemistry"
- **Biology**: 91/100 (A) - "Excellent work in molecular biology and genetics"

**Teacher: Mr. Nyamande**
- Teaches all subjects for Term 3 2024

### 🌐 Web Interface Access

You can also access the system via web browser:
1. Open a web browser
2. Navigate to `http://localhost:3000` (if serving locally) or open `index.html`
3. Choose between USSD interface or Web Login
4. Use the credentials listed above

### 🛠️ Technical Features

- **Progressive Web App (PWA)** - Can be installed on devices
- **Offline Support** - Works without internet connection
- **Responsive Design** - Works on desktop, tablet, and mobile
- **IndexedDB Database** - Local data storage
- **Service Worker** - Background sync and caching
- **USSD Simulation** - Terminal-based interface
- **Modern UI/UX** - Clean, professional design

### 🚀 Getting Started

1. Make sure Node.js is installed on your system
2. Open terminal and navigate to the project folder
3. Run `node terminal-ussd.js` for USSD interface
4. Or open `index.html` in a web browser for the web interface

### 📞 Support

For technical support or questions about the system, please refer to the documentation or contact the development team.

---

**Vision College Learning Management System**  
*Empowering Education Through Technology*
