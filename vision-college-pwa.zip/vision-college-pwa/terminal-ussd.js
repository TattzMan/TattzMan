#!/usr/bin/env node

/**
 * Vision College Terminal USSD Interface
 * Run this in your terminal with: node terminal-ussd.js
 * 
 * This simulates a USSD interface that you can access from the command line
 * Languages used: Node.js (JavaScript)
 */

const readline = require('readline');

// USSD Interface Class
class TerminalUSSD {
    constructor() {
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        this.currentUser = null;
        this.currentStep = 'welcome';
        
        // Sample database (in a real app, this would connect to your actual database)
        this.users = {
            'password123': { name: 'Tatenda', role: 'student', id: 1 },
            'teacher123': { name: 'Mr. Nyamande', role: 'teacher', id: 2 },
            'admin123': { name: 'Admin User', role: 'admin', id: 3 }
        };
        
        this.grades = [
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Mathematics',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'A',
                score: 92,
                maxScore: 100,
                comments: 'Excellent performance in algebra and geometry'
            },
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Physics',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'B+',
                score: 85,
                maxScore: 100,
                comments: 'Good understanding of mechanics and thermodynamics'
            },
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Chemistry',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'A-',
                score: 88,
                maxScore: 100,
                comments: 'Strong performance in organic chemistry'
            },
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Biology',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'A',
                score: 91,
                maxScore: 100,
                comments: 'Excellent work in molecular biology and genetics'
            }
        ];
    }

    // Display USSD screen with green theme
    displayScreen(content) {
        console.clear();
        console.log('\x1b[42m\x1b[30m%s\x1b[0m', '╔══════════════════════════════════════════════════╗');
        console.log('\x1b[42m\x1b[30m%s\x1b[0m', '║              📱 VISION COLLEGE USSD              ║');
        console.log('\x1b[42m\x1b[30m%s\x1b[0m', '╚══════════════════════════════════════════════════╝');
        console.log('\x1b[32m%s\x1b[0m', '');
        console.log(content);
        console.log('\x1b[32m%s\x1b[0m', '══════════════════════════════════════════════════');
    }

    // Start the USSD session
    start() {
        this.showWelcome();
    }

    showWelcome() {
        this.currentStep = 'welcome';
        this.displayScreen(`
\x1b[32m🎓 Welcome to Vision College Portal\x1b[0m

Please dial: \x1b[1m*123#\x1b[0m

Enter USSD Code: `);
        
        this.rl.question('', (input) => {
            if (input.trim() === '*123#') {
                this.showPasswordPrompt();
            } else {
                console.log('\x1b[31mInvalid USSD code. Please dial *123#\x1b[0m');
                setTimeout(() => this.showWelcome(), 2000);
            }
        });
    }

    showPasswordPrompt() {
        this.currentStep = 'password';
        this.displayScreen(`
\x1b[32m🔐 Vision College Authentication\x1b[0m

Enter your password: `);
        
        this.rl.question('', (password) => {
            this.authenticateUser(password.trim());
        });
    }

    authenticateUser(password) {
        console.log(''); // New line
        
        if (this.users[password]) {
            this.currentUser = this.users[password];
            console.log(`\x1b[32m✅ Login successful! Welcome, ${this.currentUser.name}\x1b[0m`);
            setTimeout(() => this.showMainMenu(), 1000);
        } else {
            console.log('\x1b[31m❌ Invalid password. Please try again.\x1b[0m');
            setTimeout(() => this.showPasswordPrompt(), 2000);
        }
    }

    showMainMenu() {
        this.currentStep = 'menu';
        this.displayScreen(`
\x1b[32m👋 Welcome, ${this.currentUser.name}!\x1b[0m

Select an option:
\x1b[1m1.\x1b[0m Student Portal
\x1b[1m2.\x1b[0m Teacher Portal  
\x1b[1m0.\x1b[0m Exit

Enter your choice: `);
        
        this.rl.question('', (choice) => {
            switch (choice.trim()) {
                case '1':
                    if (this.currentUser.role === 'student') {
                        this.showStudentPortal();
                    } else {
                        console.log('\x1b[31m❌ Access denied. You are not a student.\x1b[0m');
                        setTimeout(() => this.showMainMenu(), 2000);
                    }
                    break;
                case '2':
                    if (this.currentUser.role === 'teacher' || this.currentUser.role === 'admin') {
                        this.showTeacherPortal();
                    } else {
                        console.log('\x1b[31m❌ Access denied. You are not a teacher.\x1b[0m');
                        setTimeout(() => this.showMainMenu(), 2000);
                    }
                    break;
                case '0':
                    this.exit();
                    break;
                default:
                    console.log('\x1b[31m❌ Invalid option. Please try again.\x1b[0m');
                    setTimeout(() => this.showMainMenu(), 2000);
            }
        });
    }

    showStudentPortal() {
        this.currentStep = 'student';
        this.displayScreen(`
\x1b[32m📚 Student Portal - ${this.currentUser.name}\x1b[0m

\x1b[1m1.\x1b[0m View Term Results
\x1b[1m2.\x1b[0m View Subject Grades
\x1b[1m3.\x1b[0m Student Profile
\x1b[1m0.\x1b[0m Back to Main Menu

Enter your choice: `);
        
        this.rl.question('', (choice) => {
            switch (choice.trim()) {
                case '1':
                    this.showTermResults();
                    break;
                case '2':
                    this.showSubjectGrades();
                    break;
                case '3':
                    this.showStudentProfile();
                    break;
                case '0':
                    this.showMainMenu();
                    break;
                default:
                    console.log('\x1b[31m❌ Invalid option. Please try again.\x1b[0m');
                    setTimeout(() => this.showStudentPortal(), 2000);
            }
        });
    }

    showTermResults() {
        const studentGrades = this.grades.filter(g => g.studentId === this.currentUser.id);
        let totalScore = 0;
        let totalMax = 0;
        
        studentGrades.forEach(grade => {
            totalScore += grade.score;
            totalMax += grade.maxScore;
        });
        
        const average = Math.round((totalScore / totalMax) * 100);
        let overallGrade = 'F';
        if (average >= 90) overallGrade = 'A';
        else if (average >= 80) overallGrade = 'B';
        else if (average >= 70) overallGrade = 'C';
        else if (average >= 60) overallGrade = 'D';
        
        this.displayScreen(`
\x1b[32m📊 End of Term Results - Term 3 2024\x1b[0m
\x1b[1mStudent:\x1b[0m ${this.currentUser.name}

\x1b[1m📈 Overall Performance:\x1b[0m
• Total Score: ${totalScore}/${totalMax}
• Average: ${average}%
• Grade: \x1b[1m${overallGrade}\x1b[0m

\x1b[1m🏆 Subject Breakdown:\x1b[0m
${studentGrades.map(grade => 
    `• ${grade.subject}: ${grade.score}/${grade.maxScore} (${grade.grade})`
).join('\n')}

\x1b[1m👨‍🏫 Teacher:\x1b[0m ${studentGrades[0]?.teacherName}

Press Enter to continue...`);
        
        this.rl.question('', () => {
            this.showStudentPortal();
        });
    }

    showSubjectGrades() {
        const studentGrades = this.grades.filter(g => g.studentId === this.currentUser.id);
        
        this.displayScreen(`
\x1b[32m🏆 Subject Performance & Grades\x1b[0m
\x1b[1mStudent:\x1b[0m ${this.currentUser.name}

${studentGrades.map((grade, index) => `
\x1b[1m${index + 1}. ${grade.subject}\x1b[0m
• Score: ${grade.score}/${grade.maxScore}
• Grade: \x1b[1m${grade.grade}\x1b[0m
• Teacher: ${grade.teacherName}
• Comments: ${grade.comments}
`).join('\n')}

Press Enter to continue...`);
        
        this.rl.question('', () => {
            this.showStudentPortal();
        });
    }

    showStudentProfile() {
        this.displayScreen(`
\x1b[32m👤 Student Profile\x1b[0m

\x1b[1m📋 Personal Information:\x1b[0m
• Name: ${this.currentUser.name}
• Student ID: VC2024001
• Role: Student
• Email: tatenda@visioncollege.edu

\x1b[1m🎓 Academic Information:\x1b[0m
• Current Term: Term 3 2024
• Subjects Enrolled: 4
• Overall Grade: A-

Press Enter to continue...`);
        
        this.rl.question('', () => {
            this.showStudentPortal();
        });
    }

    showTeacherPortal() {
        this.displayScreen(`
\x1b[32m👨‍🏫 Teacher Portal - ${this.currentUser.name}\x1b[0m

\x1b[1m1.\x1b[0m View All Student Results
\x1b[1m2.\x1b[0m Manage Grades
\x1b[1m3.\x1b[0m Teacher Profile
\x1b[1m0.\x1b[0m Back to Main Menu

Enter your choice: `);
        
        this.rl.question('', (choice) => {
            switch (choice.trim()) {
                case '1':
                    this.showAllStudentResults();
                    break;
                case '2':
                    this.showGradeManagement();
                    break;
                case '3':
                    this.showTeacherProfile();
                    break;
                case '0':
                    this.showMainMenu();
                    break;
                default:
                    console.log('\x1b[31m❌ Invalid option. Please try again.\x1b[0m');
                    setTimeout(() => this.showTeacherPortal(), 2000);
            }
        });
    }

    showAllStudentResults() {
        this.displayScreen(`
\x1b[32m📊 All Student Results - Term 3 2024\x1b[0m
\x1b[1mTeacher:\x1b[0m ${this.currentUser.name}

\x1b[1m🎓 Tatenda's Performance:\x1b[0m
${this.grades.map(grade => 
    `• ${grade.subject}: ${grade.score}/${grade.maxScore} (${grade.grade})`
).join('\n')}

\x1b[1m📈 Summary:\x1b[0m
• Total Students: 1
• Average Class Performance: 89%
• Subjects Taught: 4

Press Enter to continue...`);
        
        this.rl.question('', () => {
            this.showTeacherPortal();
        });
    }

    showGradeManagement() {
        this.displayScreen(`
\x1b[32m🏆 Grade Management\x1b[0m
\x1b[1mTeacher:\x1b[0m ${this.currentUser.name}

This feature allows you to:
• Update student grades
• Add comments to assessments
• Generate progress reports
• Export grade sheets

\x1b[33m🚧 Feature under development\x1b[0m
Access the full web interface for complete functionality.

Press Enter to continue...`);
        
        this.rl.question('', () => {
            this.showTeacherPortal();
        });
    }

    showTeacherProfile() {
        this.displayScreen(`
\x1b[32m👤 Teacher Profile\x1b[0m

\x1b[1m📋 Personal Information:\x1b[0m
• Name: ${this.currentUser.name}
• Teacher ID: TCH001
• Role: Teacher
• Email: nyamande@visioncollege.edu

\x1b[1m📚 Teaching Information:\x1b[0m
• Subjects: Mathematics, Physics, Chemistry, Biology
• Students: 1 active
• Experience: Senior Teacher

Press Enter to continue...`);
        
        this.rl.question('', () => {
            this.showTeacherPortal();
        });
    }

    exit() {
        this.displayScreen(`
\x1b[32m👋 Thank you for using Vision College USSD!\x1b[0m

Session ended.
Have a great day! 🎓

\x1b[90mTo access the full web interface, visit:\x1b[0m
\x1b[36mhttp://localhost:5500\x1b[0m
`);
        this.rl.close();
        process.exit(0);
    }
}

// Start the USSD interface
console.log('\x1b[32m%s\x1b[0m', 'Starting Vision College Terminal USSD...');
console.log('\x1b[90m%s\x1b[0m', 'Languages used: Node.js (JavaScript)');
console.log('\x1b[90m%s\x1b[0m', 'Colors: Green and White theme as requested');
console.log('');

setTimeout(() => {
    const ussd = new TerminalUSSD();
    ussd.start();
}, 1000);

// Handle Ctrl+C gracefully
process.on('SIGINT', () => {
    console.log('\n\x1b[32mThank you for using Vision College USSD! 👋\x1b[0m');
    process.exit(0);
});
