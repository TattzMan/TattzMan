// Vision College PWA Service Worker
const CACHE_NAME = 'vision-college-v1';
const CACHE_URLS = [
    '/',
    '/index.html',
    '/css/styles.css',
    '/js/app.js',
    '/js/auth.js',
    '/js/database.js',
    '/manifest.json',
    // Add offline fallback page
    '/offline.html'
];

// Install event - cache resources
self.addEventListener('install', event => {
    console.log('Service Worker installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Caching app shell...');
                return cache.addAll(CACHE_URLS);
            })
            .then(() => {
                console.log('App shell cached successfully');
                // Skip waiting to activate immediately
                return self.skipWaiting();
            })
            .catch(error => {
                console.error('Failed to cache app shell:', error);
            })
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
    console.log('Service Worker activating...');
    
    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames
                        .filter(cacheName => cacheName !== CACHE_NAME)
                        .map(cacheName => {
                            console.log('Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        })
                );
            })
            .then(() => {
                console.log('Service Worker activated');
                // Claim all clients immediately
                return self.clients.claim();
            })
    );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', event => {
    // Skip non-GET requests
    if (event.request.method !== 'GET') {
        return;
    }

    // Skip requests to other origins
    if (!event.request.url.startsWith(self.location.origin)) {
        return;
    }

    event.respondWith(
        caches.match(event.request)
            .then(response => {
                // Return cached version if available
                if (response) {
                    console.log('Serving from cache:', event.request.url);
                    return response;
                }

                // Otherwise fetch from network
                console.log('Fetching from network:', event.request.url);
                return fetch(event.request)
                    .then(response => {
                        // Check if we received a valid response
                        if (!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }

                        // Clone the response for caching
                        const responseToCache = response.clone();

                        // Cache important resources
                        if (shouldCache(event.request.url)) {
                            caches.open(CACHE_NAME)
                                .then(cache => {
                                    console.log('Caching new resource:', event.request.url);
                                    cache.put(event.request, responseToCache);
                                });
                        }

                        return response;
                    })
                    .catch(() => {
                        // Network failed, try to serve offline fallback
                        console.log('Network failed for:', event.request.url);
                        return handleOfflineFallback(event.request);
                    });
            })
    );
});

// Determine if a resource should be cached
function shouldCache(url) {
    // Cache CSS, JS, images, and HTML files
    return url.includes('.css') || 
           url.includes('.js') || 
           url.includes('.png') || 
           url.includes('.jpg') || 
           url.includes('.jpeg') || 
           url.includes('.gif') || 
           url.includes('.svg') || 
           url.includes('.html') ||
           url.includes('/api/'); // API responses for offline use
}

// Handle offline fallbacks
function handleOfflineFallback(request) {
    // For HTML requests (navigation), serve offline page
    if (request.headers.get('accept').includes('text/html')) {
        return caches.match('/offline.html')
            .then(response => {
                if (response) {
                    return response;
                }
                // Fallback to index.html if offline.html not available
                return caches.match('/index.html');
            });
    }

    // For other resources, try to find a cached version
    return caches.match(request)
        .then(response => {
            if (response) {
                return response;
            }
            
            // Return a generic offline response
            return new Response('Offline - Resource not available', {
                status: 503,
                statusText: 'Service Unavailable',
                headers: new Headers({
                    'Content-Type': 'text/plain'
                })
            });
        });
}

// Background sync for offline data
self.addEventListener('sync', event => {
    console.log('Background sync triggered:', event.tag);
    
    if (event.tag === 'vision-college-sync') {
        event.waitUntil(syncOfflineData());
    }
});

// Sync offline data when connection is restored
async function syncOfflineData() {
    try {
        console.log('Syncing offline data...');
        
        // This would typically sync with your backend API
        // For now, we'll just log the sync attempt
        
        // In a real implementation, you would:
        // 1. Get offline data from IndexedDB
        // 2. Send it to your server
        // 3. Update local data with server response
        // 4. Clear sync queue
        
        const clients = await self.clients.matchAll();
        clients.forEach(client => {
            client.postMessage({
                type: 'SYNC_COMPLETE',
                data: { success: true }
            });
        });
        
        console.log('Offline data sync completed');
    } catch (error) {
        console.error('Offline data sync failed:', error);
        
        const clients = await self.clients.matchAll();
        clients.forEach(client => {
            client.postMessage({
                type: 'SYNC_FAILED',
                data: { error: error.message }
            });
        });
    }
}

// Handle push notifications (for future use)
self.addEventListener('push', event => {
    console.log('Push notification received');
    
    const options = {
        body: event.data ? event.data.text() : 'New notification from Vision College',
        icon: '/icons/icon-192x192.png',
        badge: '/icons/icon-72x72.png',
        vibrate: [200, 100, 200],
        tag: 'vision-college-notification',
        actions: [
            {
                action: 'view',
                title: 'View',
                icon: '/icons/icon-72x72.png'
            },
            {
                action: 'dismiss',
                title: 'Dismiss'
            }
        ]
    };

    event.waitUntil(
        self.registration.showNotification('Vision College', options)
    );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
    console.log('Notification clicked:', event.action);
    
    event.notification.close();

    if (event.action === 'view') {
        // Open the app
        event.waitUntil(
            clients.matchAll({ type: 'window', includeUncontrolled: true })
                .then(clientList => {
                    // If app is already open, focus it
                    for (let client of clientList) {
                        if (client.url.includes(self.location.origin) && 'focus' in client) {
                            return client.focus();
                        }
                    }
                    
                    // Otherwise, open a new window
                    if (clients.openWindow) {
                        return clients.openWindow('/');
                    }
                })
        );
    }
});

// Message handling from main app
self.addEventListener('message', event => {
    console.log('Service Worker received message:', event.data);
    
    if (event.data && event.data.type) {
        switch (event.data.type) {
            case 'SKIP_WAITING':
                self.skipWaiting();
                break;
                
            case 'SYNC_REQUEST':
                // Register for background sync
                self.registration.sync.register('vision-college-sync')
                    .then(() => {
                        console.log('Background sync registered');
                    })
                    .catch(error => {
                        console.error('Background sync registration failed:', error);
                    });
                break;
                
            case 'CACHE_CONTENT':
                // Cache specific content for offline use
                const { url, data } = event.data;
                if (url && data) {
                    cacheContent(url, data);
                }
                break;
        }
    }
});

// Cache specific content (like notes or syllabus)
async function cacheContent(url, data) {
    try {
        const cache = await caches.open(CACHE_NAME);
        const response = new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' }
        });
        
        await cache.put(url, response);
        console.log('Content cached for offline use:', url);
    } catch (error) {
        console.error('Failed to cache content:', error);
    }
}

// Periodic background sync (if supported)
self.addEventListener('periodicsync', event => {
    if (event.tag === 'vision-college-periodic-sync') {
        event.waitUntil(syncOfflineData());
    }
});

console.log('Vision College Service Worker loaded');
