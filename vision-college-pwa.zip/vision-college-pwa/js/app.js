// Vision College PWA - Main Application Logic

// Global variables
let currentUser = null;
let isOnline = navigator.onLine;

// Application initialization
document.addEventListener('DOMContentLoaded', async () => {
    console.log('Vision College PWA Starting...');
    
    try {
        // Initialize database
        console.log('Initializing database...');
        await visionDB.init();
        console.log('Database initialized successfully');
        
        // Wait a bit for database to be ready
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Initialize authentication
        console.log('Initializing authentication...');
        const session = await authManager.init();
        
        // Update online status
        visionDB.updateOnlineStatus();
        
        // Set up event listeners
        setupEventListeners();
        
        // Check if user has active session
        if (session) {
            console.log('Existing session found:', session.role);
            if (session.role === 'student') {
                showStudentDashboard(session);
            } else if (session.role === 'teacher') {
                showTeacherDashboard(session);
            }
        } else {
            // Show initial USSD interface
            console.log('No existing session, showing USSD interface');
            showUSSD();
        }
        
        // Add debug info to console
        console.log('=== VISION COLLEGE PWA DEBUG INFO ===');
        console.log('USSD Credentials:');
        console.log('- Student: password123');
        console.log('- Teacher: teacher123');
        console.log('- Admin: admin123');
        console.log('Web Login Credentials:');
        console.log('- student1 / password123 (Student)');
        console.log('- teacher1 / teacher123 (Teacher)');
        console.log('- admin / admin123 (Teacher)');
        console.log('To reset database: resetDatabase()');
        console.log('====================================');
        
        console.log('Vision College PWA Ready!');
    } catch (error) {
        console.error('Failed to initialize app:', error);
        showNotification('Failed to initialize application. Check console for details.', 'error');
        
        // Try to show USSD interface anyway
        showUSSD();
    }
});

// Set up event listeners
function setupEventListeners() {
    // Login form submission
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleWebLogin);
    }
    
    // Upload forms
    const notesUploadForm = document.getElementById('notes-upload-form');
    const syllabusUploadForm = document.getElementById('syllabus-upload-form');
    
    if (notesUploadForm) {
        notesUploadForm.addEventListener('submit', handleNotesUpload);
    }
    
    if (syllabusUploadForm) {
        syllabusUploadForm.addEventListener('submit', handleSyllabusUpload);
    }
    
    // Grade entry form
    const gradeEntryForm = document.getElementById('grade-entry-form');
    if (gradeEntryForm) {
        gradeEntryForm.addEventListener('submit', handleGradeEntry);
    }
    
    // USSD input enter key handling
    const ussdDialInput = document.getElementById('ussd-dial');
    const ussdPassInput = document.getElementById('ussd-pass');
    
    if (ussdDialInput) {
        ussdDialInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleUSSDDial();
            }
        });
    }
    
    if (ussdPassInput) {
        ussdPassInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleUSSDPassword();
            }
        });
    }
}

// Student Dashboard Functions

function showStudentSection(section) {
    // Remove active class from all nav buttons
    document.querySelectorAll('#student-dashboard .nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Remove active class from all sections
    document.querySelectorAll('#student-dashboard .section').forEach(sec => {
        sec.classList.remove('active');
    });
    
    // Add active class to clicked nav button
    event.target.classList.add('active');
    
    // Show selected section
    document.getElementById(`student-${section}`).classList.add('active');
    
    // Load content based on section
    switch (section) {
        case 'results':
            loadStudentResults();
            break;
        case 'grades':
            loadStudentGrades();
            break;
        case 'notes':
            loadStudentNotes();
            break;
        case 'syllabus':
            loadStudentSyllabus();
            break;
        case 'profile':
            loadStudentProfile();
            break;
    }
}

async function loadStudentResults() {
    try {
        const resultsList = document.getElementById('results-list');
        resultsList.innerHTML = '<div class="loading">Loading results...</div>';
        
        const user = authManager.getCurrentUser();
        const grades = await visionDB.getStudentGrades(user.id);
        
        if (grades.length === 0) {
            resultsList.innerHTML = '<div class="empty-state">No results available</div>';
            return;
        }
        
        // Calculate overall performance
        let totalScore = 0;
        let totalMax = 0;
        grades.forEach(grade => {
            totalScore += grade.score;
            totalMax += grade.maxScore;
        });
        
        const average = Math.round((totalScore / totalMax) * 100);
        let overallGrade = 'F';
        if (average >= 90) overallGrade = 'A';
        else if (average >= 80) overallGrade = 'B';
        else if (average >= 70) overallGrade = 'C';
        else if (average >= 60) overallGrade = 'D';
        
        let resultsHTML = `
            <div class="results-summary">
                <h3>📊 Overall Performance Summary</h3>
                <div class="performance-stats">
                    <div class="stat-card">
                        <h4>Total Score</h4>
                        <p class="score">${totalScore}/${totalMax}</p>
                    </div>
                    <div class="stat-card">
                        <h4>Average</h4>
                        <p class="percentage">${average}%</p>
                    </div>
                    <div class="stat-card">
                        <h4>Overall Grade</h4>
                        <p class="grade grade-${overallGrade.toLowerCase()}">${overallGrade}</p>
                    </div>
                </div>
            </div>
            <div class="subjects-breakdown">
                <h3>🏆 Subject Performance</h3>
        `;
        
        grades.forEach(grade => {
            resultsHTML += `
                <div class="subject-result">
                    <h4>${grade.subject}</h4>
                    <div class="subject-details">
                        <span class="subject-score">${grade.score}/${grade.maxScore}</span>
                        <span class="subject-grade grade-${grade.grade.toLowerCase().replace('+', 'plus').replace('-', 'minus')}">${grade.grade}</span>
                    </div>
                    <p class="teacher">Teacher: ${grade.teacherName}</p>
                </div>
            `;
        });
        
        resultsHTML += '</div>';
        resultsList.innerHTML = resultsHTML;
        
    } catch (error) {
        console.error('Failed to load results:', error);
        document.getElementById('results-list').innerHTML = '<div class="error">Failed to load results</div>';
    }
}

async function loadStudentGrades() {
    try {
        const gradesList = document.getElementById('grades-list');
        gradesList.innerHTML = '<div class="loading">Loading grades...</div>';
        
        const user = authManager.getCurrentUser();
        const grades = await visionDB.getStudentGrades(user.id);
        
        if (grades.length === 0) {
            gradesList.innerHTML = '<div class="empty-state">No grades available</div>';
            return;
        }
        
        let gradesHTML = '';
        grades.forEach(grade => {
            gradesHTML += `
                <div class="grade-item">
                    <div class="grade-header">
                        <h3>${grade.subject}</h3>
                        <span class="grade-badge grade-${grade.grade.toLowerCase().replace('+', 'plus').replace('-', 'minus')}">${grade.grade}</span>
                    </div>
                    <div class="grade-details">
                        <div class="score-info">
                            <span class="score">Score: ${grade.score}/${grade.maxScore}</span>
                            <span class="percentage">(${Math.round((grade.score/grade.maxScore)*100)}%)</span>
                        </div>
                        <div class="meta-info">
                            <p><strong>Teacher:</strong> ${grade.teacherName}</p>
                            <p><strong>Term:</strong> ${grade.term}</p>
                        </div>
                        <div class="comments">
                            <p><strong>Comments:</strong> ${grade.comments}</p>
                        </div>
                    </div>
                </div>
            `;
        });
        
        gradesList.innerHTML = gradesHTML;
    } catch (error) {
        console.error('Failed to load grades:', error);
        document.getElementById('grades-list').innerHTML = '<div class="error">Failed to load grades</div>';
    }
}

async function loadStudentNotes() {
    try {
        const notesList = document.getElementById('notes-list');
        notesList.innerHTML = '<div class="loading">Loading notes...</div>';
        
        const notes = await visionDB.getNotes();
        
        if (notes.length === 0) {
            notesList.innerHTML = '<div class="empty-state">No notes available</div>';
            return;
        }
        
        let notesHTML = '';
        notes.forEach(note => {
            notesHTML += `
                <div class="content-item" data-id="${note.id}">
                    <h3>${note.title}</h3>
                    <div class="meta">
                        Subject: ${note.subject} | By: ${note.teacherName} | 
                        ${new Date(note.dateCreated).toLocaleDateString()}
                        ${!isOnline && note.isOfflineAvailable ? '<span class="offline-badge">📱 Available Offline</span>' : ''}
                    </div>
                    <div class="content">${note.content.substring(0, 150)}${note.content.length > 150 ? '...' : ''}</div>
                    <div class="actions">
                        <button class="btn-view" onclick="viewNote(${note.id})">View Full Note</button>
                        <button class="btn-download" onclick="downloadNote(${note.id})">📥 Download Note</button>
                        ${note.fileAttachment ? '<button class="btn-view" onclick="downloadAttachment(' + note.id + ')">Download File</button>' : ''}
                    </div>
                </div>
            `;
        });
        
        notesList.innerHTML = notesHTML;
    } catch (error) {
        console.error('Failed to load notes:', error);
        document.getElementById('notes-list').innerHTML = '<div class="error">Failed to load notes</div>';
    }
}

async function loadStudentSyllabus() {
    try {
        const syllabusList = document.getElementById('syllabus-list');
        syllabusList.innerHTML = '<div class="loading">Loading syllabus...</div>';
        
        const syllabusItems = await visionDB.getSyllabus();
        
        if (syllabusItems.length === 0) {
            syllabusList.innerHTML = '<div class="empty-state">No syllabus available</div>';
            return;
        }
        
        let syllabusHTML = '';
        syllabusItems.forEach(syllabus => {
            syllabusHTML += `
                <div class="content-item" data-id="${syllabus.id}">
                    <h3>${syllabus.title}</h3>
                    <div class="meta">
                        Subject: ${syllabus.subject} | By: ${syllabus.teacherName} | 
                        ${new Date(syllabus.dateCreated).toLocaleDateString()}
                        ${!isOnline && syllabus.isOfflineAvailable ? '<span class="offline-badge">📱 Available Offline</span>' : ''}
                    </div>
                    <div class="content">${syllabus.content.substring(0, 150)}${syllabus.content.length > 150 ? '...' : ''}</div>
                    <div class="actions">
                        <button class="btn-view" onclick="viewSyllabus(${syllabus.id})">View Full Syllabus</button>
                        <button class="btn-download" onclick="downloadSyllabus(${syllabus.id})">📥 Download Syllabus</button>
                        ${syllabus.fileAttachment ? '<button class="btn-view" onclick="downloadAttachment(' + syllabus.id + ', \'syllabus\')">Download File</button>' : ''}
                    </div>
                </div>
            `;
        });
        
        syllabusList.innerHTML = syllabusHTML;
    } catch (error) {
        console.error('Failed to load syllabus:', error);
        document.getElementById('syllabus-list').innerHTML = '<div class="error">Failed to load syllabus</div>';
    }
}

function loadStudentProfile() {
    const user = authManager.getCurrentUser();
    const profileContent = document.getElementById('student-profile-content');
    
    profileContent.innerHTML = `
        <div class="profile-info">
            <h3>Student Information</h3>
            <div class="profile-field">
                <label>Name:</label>
                <span>${user.name}</span>
            </div>
            <div class="profile-field">
                <label>Student ID:</label>
                <span>${user.studentId || 'Not Available'}</span>
            </div>
            <div class="profile-field">
                <label>Email:</label>
                <span>${user.email}</span>
            </div>
            <div class="profile-field">
                <label>Role:</label>
                <span>Student</span>
            </div>
            <div class="profile-field">
                <label>Login Time:</label>
                <span>${new Date(authManager.getCurrentSession().loginTime).toLocaleString()}</span>
            </div>
        </div>
        <div class="profile-actions">
            <button onclick="showChangePasswordDialog()" class="btn-edit">Change Password</button>
        </div>
    `;
}

// Teacher Dashboard Functions

function showTeacherSection(section) {
    // Remove active class from all nav buttons
    document.querySelectorAll('#teacher-dashboard .nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Remove active class from all sections
    document.querySelectorAll('#teacher-dashboard .section').forEach(sec => {
        sec.classList.remove('active');
    });
    
    // Add active class to clicked nav button
    event.target.classList.add('active');
    
    // Show selected section
    document.getElementById(`teacher-${section}`).classList.add('active');
    
    // Load content based on section
    switch (section) {
        case 'manage':
            loadTeacherContent();
            break;
        case 'students':
            loadStudentsList();
            setupGradeEntryForm();
            break;
        case 'profile':
            loadTeacherProfile();
            break;
    }
}

async function handleNotesUpload(event) {
    event.preventDefault();
    
    const title = document.getElementById('note-title').value.trim();
    const subject = document.getElementById('note-subject').value.trim();
    const content = document.getElementById('note-content').value.trim();
    const fileInput = document.getElementById('note-file');
    
    if (!title || !subject || !content) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        const user = authManager.getCurrentUser();
        const noteData = {
            title: title,
            subject: subject,
            content: content,
            teacherId: user.id,
            teacherName: user.name,
            dateCreated: new Date().toISOString(),
            lastModified: new Date().toISOString(),
            isOfflineAvailable: true
        };
        
        // Handle file attachment if present
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            // In a real app, you'd upload this to a server or convert to base64
            noteData.fileAttachment = {
                name: file.name,
                size: file.size,
                type: file.type,
                lastModified: file.lastModified
            };
        }
        
        await visionDB.addNote(noteData);
        
        showNotification('Note uploaded successfully!', 'success');
        document.getElementById('notes-upload-form').reset();
        
        // Refresh content if in manage section
        if (document.getElementById('teacher-manage').classList.contains('active')) {
            loadTeacherContent();
        }
        
        showLoading(false);
    } catch (error) {
        console.error('Failed to upload note:', error);
        showNotification('Failed to upload note', 'error');
        showLoading(false);
    }
}

async function handleSyllabusUpload(event) {
    event.preventDefault();
    
    const title = document.getElementById('syllabus-title').value.trim();
    const subject = document.getElementById('syllabus-subject').value.trim();
    const content = document.getElementById('syllabus-content').value.trim();
    const fileInput = document.getElementById('syllabus-file');
    
    if (!title || !subject || !content) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        const user = authManager.getCurrentUser();
        const syllabusData = {
            title: title,
            subject: subject,
            content: content,
            teacherId: user.id,
            teacherName: user.name,
            dateCreated: new Date().toISOString(),
            lastModified: new Date().toISOString(),
            isOfflineAvailable: true
        };
        
        // Handle file attachment if present
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            syllabusData.fileAttachment = {
                name: file.name,
                size: file.size,
                type: file.type,
                lastModified: file.lastModified
            };
        }
        
        await visionDB.addSyllabus(syllabusData);
        
        showNotification('Syllabus uploaded successfully!', 'success');
        document.getElementById('syllabus-upload-form').reset();
        
        // Refresh content if in manage section
        if (document.getElementById('teacher-manage').classList.contains('active')) {
            loadTeacherContent();
        }
        
        showLoading(false);
    } catch (error) {
        console.error('Failed to upload syllabus:', error);
        showNotification('Failed to upload syllabus', 'error');
        showLoading(false);
    }
}

function showManageContent(type) {
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Load content
    if (type === 'notes') {
        loadTeacherNotes();
    } else if (type === 'syllabus') {
        loadTeacherSyllabus();
    }
}

async function loadTeacherContent() {
    // Load notes by default
    loadTeacherNotes();
}

async function loadTeacherNotes() {
    try {
        const user = authManager.getCurrentUser();
        const manageContent = document.getElementById('manage-content');
        manageContent.innerHTML = '<div class="loading">Loading notes...</div>';
        
        const notes = await visionDB.getNotes();
        const userNotes = notes.filter(note => note.teacherId === user.id);
        
        if (userNotes.length === 0) {
            manageContent.innerHTML = '<div class="empty-state">You haven\'t created any notes yet</div>';
            return;
        }
        
        let notesHTML = '<h3>Your Notes</h3><div class="content-list">';
        userNotes.forEach(note => {
            notesHTML += `
                <div class="content-item" data-id="${note.id}">
                    <h3>${note.title}</h3>
                    <div class="meta">
                        Subject: ${note.subject} | Created: ${new Date(note.dateCreated).toLocaleDateString()}
                        ${note.lastModified !== note.dateCreated ? '| Modified: ' + new Date(note.lastModified).toLocaleDateString() : ''}
                    </div>
                    <div class="content">${note.content.substring(0, 100)}${note.content.length > 100 ? '...' : ''}</div>
                    <div class="actions">
                        <button class="btn-view" onclick="viewNote(${note.id})">View</button>
                        <button class="btn-edit" onclick="editNote(${note.id})">Edit</button>
                        <button class="btn-delete" onclick="deleteNote(${note.id})">Delete</button>
                    </div>
                </div>
            `;
        });
        notesHTML += '</div>';
        
        manageContent.innerHTML = notesHTML;
    } catch (error) {
        console.error('Failed to load teacher notes:', error);
        document.getElementById('manage-content').innerHTML = '<div class="error">Failed to load notes</div>';
    }
}

async function loadTeacherSyllabus() {
    try {
        const user = authManager.getCurrentUser();
        const manageContent = document.getElementById('manage-content');
        manageContent.innerHTML = '<div class="loading">Loading syllabus...</div>';
        
        const syllabusItems = await visionDB.getSyllabus();
        const userSyllabus = syllabusItems.filter(syllabus => syllabus.teacherId === user.id);
        
        if (userSyllabus.length === 0) {
            manageContent.innerHTML = '<div class="empty-state">You haven\'t created any syllabus yet</div>';
            return;
        }
        
        let syllabusHTML = '<h3>Your Syllabus</h3><div class="content-list">';
        userSyllabus.forEach(syllabus => {
            syllabusHTML += `
                <div class="content-item" data-id="${syllabus.id}">
                    <h3>${syllabus.title}</h3>
                    <div class="meta">
                        Subject: ${syllabus.subject} | Created: ${new Date(syllabus.dateCreated).toLocaleDateString()}
                        ${syllabus.lastModified !== syllabus.dateCreated ? '| Modified: ' + new Date(syllabus.lastModified).toLocaleDateString() : ''}
                    </div>
                    <div class="content">${syllabus.content.substring(0, 100)}${syllabus.content.length > 100 ? '...' : ''}</div>
                    <div class="actions">
                        <button class="btn-view" onclick="viewSyllabus(${syllabus.id})">View</button>
                        <button class="btn-edit" onclick="editSyllabus(${syllabus.id})">Edit</button>
                        <button class="btn-delete" onclick="deleteSyllabus(${syllabus.id})">Delete</button>
                    </div>
                </div>
            `;
        });
        syllabusHTML += '</div>';
        
        manageContent.innerHTML = syllabusHTML;
    } catch (error) {
        console.error('Failed to load teacher syllabus:', error);
        document.getElementById('manage-content').innerHTML = '<div class="error">Failed to load syllabus</div>';
    }
}

async function loadStudentsList() {
    try {
        const studentsListDiv = document.getElementById('students-list');
        studentsListDiv.innerHTML = '<div class="loading">Loading students...</div>';
        
        // Get all students from the database
        const users = await visionDB.getAllUsers();
        const students = users.filter(user => user.role === 'student');
        
        if (students.length === 0) {
            studentsListDiv.innerHTML = '<div class="empty-state">No students found in the system</div>';
            return;
        }
        
        // Get grades for performance overview
        const allGrades = await visionDB.getAllGrades();
        
        let studentsHTML = `
            <div class="students-header">
                <h3>👥 Enrolled Students (${students.length})</h3>
                <p>Overview of all students in the system</p>
            </div>
            <div class="students-grid">
        `;
        
        students.forEach(student => {
            // Calculate student's performance
            const studentGrades = allGrades.filter(grade => grade.studentId === student.id);
            let averageGrade = 'Not Graded';
            let totalSubjects = studentGrades.length;
            
            if (studentGrades.length > 0) {
                let totalScore = 0;
                let totalMax = 0;
                studentGrades.forEach(grade => {
                    totalScore += grade.score;
                    totalMax += grade.maxScore;
                });
                const average = Math.round((totalScore / totalMax) * 100);
                if (average >= 90) averageGrade = 'A';
                else if (average >= 80) averageGrade = 'B';
                else if (average >= 70) averageGrade = 'C';
                else if (average >= 60) averageGrade = 'D';
                else averageGrade = 'F';
            }
            
            studentsHTML += `
                <div class="student-card">
                    <div class="student-avatar">
                        <div class="avatar-circle">${student.name.charAt(0).toUpperCase()}</div>
                    </div>
                    <div class="student-info">
                        <h4>${student.name}</h4>
                        <p class="student-id">ID: ${student.studentId || student.id}</p>
                        <p class="student-email">${student.email}</p>
                        <div class="student-stats">
                            <span class="stat">📚 ${totalSubjects} Subjects</span>
                            <span class="grade-display grade-${averageGrade.toLowerCase()}">${averageGrade}</span>
                        </div>
                    </div>
                    <div class="student-actions">
                        <button class="btn-view" onclick="viewStudentDetails(${student.id})">View Details</button>
                        <button class="btn-edit" onclick="sendMessage(${student.id})">Message</button>
                    </div>
                </div>
            `;
        });
        
        studentsHTML += `
            </div>
            <div class="students-summary">
                <h4>📊 Class Statistics</h4>
                <div class="class-stats">
                    <div class="stat-item">
                        <span class="stat-label">Total Students:</span>
                        <span class="stat-value">${students.length}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Active Students:</span>
                        <span class="stat-value">${students.length}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Subjects Taught:</span>
                        <span class="stat-value">4</span>
                    </div>
                </div>
            </div>
        `;
        
        studentsListDiv.innerHTML = studentsHTML;
    } catch (error) {
        console.error('Failed to load students list:', error);
        document.getElementById('students-list').innerHTML = '<div class="error">Failed to load students</div>';
    }
}

function loadTeacherProfile() {
    const user = authManager.getCurrentUser();
    const profileContent = document.getElementById('teacher-profile-content');
    
    profileContent.innerHTML = `
        <div class="profile-info">
            <h3>Teacher Information</h3>
            <div class="profile-field">
                <label>Name:</label>
                <span>${user.name}</span>
            </div>
            <div class="profile-field">
                <label>Teacher ID:</label>
                <span>${user.teacherId || 'Not Available'}</span>
            </div>
            <div class="profile-field">
                <label>Email:</label>
                <span>${user.email}</span>
            </div>
            <div class="profile-field">
                <label>Subjects:</label>
                <span>${user.subjects ? user.subjects.join(', ') : 'Not specified'}</span>
            </div>
            <div class="profile-field">
                <label>Role:</label>
                <span>Teacher</span>
            </div>
            <div class="profile-field">
                <label>Login Time:</label>
                <span>${new Date(authManager.getCurrentSession().loginTime).toLocaleString()}</span>
            </div>
        </div>
        <div class="profile-actions">
            <button onclick="showChangePasswordDialog()" class="btn-edit">Change Password</button>
        </div>
    `;
}

// Content viewing functions

async function viewNote(noteId) {
    try {
        const notes = await visionDB.getNotes();
        const note = notes.find(n => n.id === noteId);
        
        if (!note) {
            showNotification('Note not found', 'error');
            return;
        }
        
        showContentModal('Note', note);
    } catch (error) {
        console.error('Failed to view note:', error);
        showNotification('Failed to load note', 'error');
    }
}

async function viewSyllabus(syllabusId) {
    try {
        const syllabusItems = await visionDB.getSyllabus();
        const syllabus = syllabusItems.find(s => s.id === syllabusId);
        
        if (!syllabus) {
            showNotification('Syllabus not found', 'error');
            return;
        }
        
        showContentModal('Syllabus', syllabus);
    } catch (error) {
        console.error('Failed to view syllabus:', error);
        showNotification('Failed to load syllabus', 'error');
    }
}

function showContentModal(type, content) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>${content.title}</h2>
                <button class="modal-close" onclick="closeModal()">×</button>
            </div>
            <div class="modal-body">
                <div class="content-meta">
                    <p><strong>Subject:</strong> ${content.subject}</p>
                    <p><strong>By:</strong> ${content.teacherName}</p>
                    <p><strong>Created:</strong> ${new Date(content.dateCreated).toLocaleString()}</p>
                    ${content.lastModified !== content.dateCreated ? 
                        `<p><strong>Last Modified:</strong> ${new Date(content.lastModified).toLocaleString()}</p>` : ''}
                </div>
                <div class="content-text">
                    ${content.content.replace(/\n/g, '<br>')}
                </div>
                ${content.fileAttachment ? 
                    `<div class="file-attachment">
                        <p><strong>Attachment:</strong> ${content.fileAttachment.name} (${Math.round(content.fileAttachment.size / 1024)}KB)</p>
                    </div>` : ''}
            </div>
        </div>
    `;
    
    // Add modal styles
    if (!document.querySelector('style[data-modal-styles]')) {
        const modalStyles = document.createElement('style');
        modalStyles.setAttribute('data-modal-styles', 'true');
        modalStyles.textContent = `
            .modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 10000;
            }
            .modal-content {
                background: white;
                border-radius: 10px;
                max-width: 90%;
                max-height: 90%;
                overflow-y: auto;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            }
            .modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 20px;
                border-bottom: 1px solid #eee;
            }
            .modal-close {
                background: none;
                border: none;
                font-size: 24px;
                cursor: pointer;
                color: #999;
            }
            .modal-body {
                padding: 20px;
            }
            .content-meta {
                background: #f5f5f5;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
            }
            .content-text {
                line-height: 1.6;
                color: #333;
            }
            .file-attachment {
                margin-top: 20px;
                padding: 10px;
                background: #e3f2fd;
                border-radius: 5px;
            }
        `;
        document.head.appendChild(modalStyles);
    }
    
    document.body.appendChild(modal);
    
    // Close on backdrop click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });
}

function closeModal() {
    const modal = document.querySelector('.modal-overlay');
    if (modal) {
        document.body.removeChild(modal);
    }
}

// Delete functions
async function deleteNote(noteId) {
    if (confirm('Are you sure you want to delete this note?')) {
        try {
            await visionDB.deleteNote(noteId);
            showNotification('Note deleted successfully', 'success');
            loadTeacherNotes();
        } catch (error) {
            console.error('Failed to delete note:', error);
            showNotification('Failed to delete note', 'error');
        }
    }
}

async function deleteSyllabus(syllabusId) {
    if (confirm('Are you sure you want to delete this syllabus?')) {
        try {
            await visionDB.deleteSyllabus(syllabusId);
            showNotification('Syllabus deleted successfully', 'success');
            loadTeacherSyllabus();
        } catch (error) {
            console.error('Failed to delete syllabus:', error);
            showNotification('Failed to delete syllabus', 'error');
        }
    }
}

// Utility functions
function showChangePasswordDialog() {
    showNotification('Change password feature will be implemented in future updates', 'info');
}

function downloadAttachment(itemId, type = 'notes') {
    showNotification('File download feature will be implemented with server integration', 'info');
}

function editNote(noteId) {
    showNotification('Edit note feature will be implemented in future updates', 'info');
}

function editSyllabus(syllabusId) {
    showNotification('Edit syllabus feature will be implemented in future updates', 'info');
}

// Student management helper functions
function viewStudentDetails(studentId) {
    viewStudentGrades(studentId);
}

function sendMessage(studentId) {
    showNotification('Student messaging feature will be implemented in future updates', 'info');
}

// Debug function to reset database
window.resetDatabase = async function() {
    if (confirm('This will delete all data and reset the database. Are you sure?')) {
        try {
            // Delete the database
            indexedDB.deleteDatabase('VisionCollegeDB');
            console.log('Database deleted');
            
            // Reload the page to reinitialize
            setTimeout(() => {
                location.reload();
            }, 1000);
            
            showNotification('Database reset! Page will reload...', 'info');
        } catch (error) {
            console.error('Failed to reset database:', error);
            showNotification('Failed to reset database', 'error');
        }
    }
};

// Debug function to show users
window.showUsers = async function() {
    try {
        const transaction = visionDB.db.transaction(['users'], 'readonly');
        const store = transaction.objectStore('users');
        const request = store.getAll();
        
        request.onsuccess = () => {
            console.log('All users in database:', request.result);
        };
    } catch (error) {
        console.error('Failed to show users:', error);
    }
};

// Download functionality for notes and syllabus

// Download note as text file
async function downloadNote(noteId) {
    try {
        const notes = await visionDB.getNotes();
        const note = notes.find(n => n.id === noteId);
        
        if (!note) {
            showNotification('Note not found', 'error');
            return;
        }
        
        // Create download content
        const content = `Vision College - Study Note
${'='.repeat(50)}

Title: ${note.title}
Subject: ${note.subject}
Teacher: ${note.teacherName}
Date Created: ${new Date(note.dateCreated).toLocaleString()}
${note.lastModified !== note.dateCreated ? `Last Modified: ${new Date(note.lastModified).toLocaleString()}` : ''}

${'='.repeat(50)}
CONTENT:
${'='.repeat(50)}

${note.content}

${'='.repeat(50)}
Generated by Vision College PWA
${new Date().toLocaleString()}`;
        
        // Generate filename
        const filename = `${note.subject}_${note.title.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
        
        // Create and trigger download
        downloadFile(content, filename, 'text/plain');
        
        showNotification(`📥 Downloaded: ${note.title}`, 'success');
    } catch (error) {
        console.error('Failed to download note:', error);
        showNotification('Failed to download note', 'error');
    }
}

// Download syllabus as text file
async function downloadSyllabus(syllabusId) {
    try {
        const syllabusItems = await visionDB.getSyllabus();
        const syllabus = syllabusItems.find(s => s.id === syllabusId);
        
        if (!syllabus) {
            showNotification('Syllabus not found', 'error');
            return;
        }
        
        // Create download content
        const content = `Vision College - Course Syllabus
${'='.repeat(50)}

Title: ${syllabus.title}
Subject: ${syllabus.subject}
Teacher: ${syllabus.teacherName}
Date Created: ${new Date(syllabus.dateCreated).toLocaleString()}
${syllabus.lastModified !== syllabus.dateCreated ? `Last Modified: ${new Date(syllabus.lastModified).toLocaleString()}` : ''}

${'='.repeat(50)}
SYLLABUS CONTENT:
${'='.repeat(50)}

${syllabus.content}

${'='.repeat(50)}
Generated by Vision College PWA
${new Date().toLocaleString()}`;
        
        // Generate filename
        const filename = `${syllabus.subject}_Syllabus_${syllabus.title.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
        
        // Create and trigger download
        downloadFile(content, filename, 'text/plain');
        
        showNotification(`📥 Downloaded: ${syllabus.title}`, 'success');
    } catch (error) {
        console.error('Failed to download syllabus:', error);
        showNotification('Failed to download syllabus', 'error');
    }
}

// Generic file download function
function downloadFile(content, filename, mimeType) {
    // Create a Blob with the content
    const blob = new Blob([content], { type: mimeType });
    
    // Create a temporary URL for the blob
    const url = URL.createObjectURL(blob);
    
    // Create a temporary anchor element and trigger download
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    
    // Add to DOM, click, and remove
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up the temporary URL
    URL.revokeObjectURL(url);
}

// Download all notes for a student
async function downloadAllNotes() {
    try {
        const notes = await visionDB.getNotes();
        
        if (notes.length === 0) {
            showNotification('No notes available to download', 'info');
            return;
        }
        
        let allNotesContent = `Vision College - All Study Notes\n${'='.repeat(60)}\n\n`;
        
        notes.forEach((note, index) => {
            allNotesContent += `\n${index + 1}. ${note.title}\n`;
            allNotesContent += `Subject: ${note.subject}\n`;
            allNotesContent += `Teacher: ${note.teacherName}\n`;
            allNotesContent += `Date: ${new Date(note.dateCreated).toLocaleDateString()}\n`;
            allNotesContent += `${'-'.repeat(40)}\n`;
            allNotesContent += `${note.content}\n\n`;
        });
        
        allNotesContent += `\n${'='.repeat(60)}\nGenerated by Vision College PWA\n${new Date().toLocaleString()}`;
        
        const filename = `VisionCollege_AllNotes_${new Date().toISOString().split('T')[0]}.txt`;
        downloadFile(allNotesContent, filename, 'text/plain');
        
        showNotification(`📥 Downloaded all notes (${notes.length} items)`, 'success');
    } catch (error) {
        console.error('Failed to download all notes:', error);
        showNotification('Failed to download all notes', 'error');
    }
}

// Download all syllabus for a student
async function downloadAllSyllabus() {
    try {
        const syllabusItems = await visionDB.getSyllabus();
        
        if (syllabusItems.length === 0) {
            showNotification('No syllabus available to download', 'info');
            return;
        }
        
        let allSyllabusContent = `Vision College - All Course Syllabus\n${'='.repeat(60)}\n\n`;
        
        syllabusItems.forEach((syllabus, index) => {
            allSyllabusContent += `\n${index + 1}. ${syllabus.title}\n`;
            allSyllabusContent += `Subject: ${syllabus.subject}\n`;
            allSyllabusContent += `Teacher: ${syllabus.teacherName}\n`;
            allSyllabusContent += `Date: ${new Date(syllabus.dateCreated).toLocaleDateString()}\n`;
            allSyllabusContent += `${'-'.repeat(40)}\n`;
            allSyllabusContent += `${syllabus.content}\n\n`;
        });
        
        allSyllabusContent += `\n${'='.repeat(60)}\nGenerated by Vision College PWA\n${new Date().toLocaleString()}`;
        
        const filename = `VisionCollege_AllSyllabus_${new Date().toISOString().split('T')[0]}.txt`;
        downloadFile(allSyllabusContent, filename, 'text/plain');
        
        showNotification(`📥 Downloaded all syllabus (${syllabusItems.length} items)`, 'success');
    } catch (error) {
        console.error('Failed to download all syllabus:', error);
        showNotification('Failed to download all syllabus', 'error');
    }
}

// Grading Functions for Teachers

// Setup grade entry form with student options
async function setupGradeEntryForm() {
    try {
        const users = await visionDB.getAllUsers();
        const students = users.filter(user => user.role === 'student');
        
        const gradeStudentSelect = document.getElementById('grade-student');
        if (gradeStudentSelect) {
            // Clear existing options except the first one
            while (gradeStudentSelect.children.length > 1) {
                gradeStudentSelect.removeChild(gradeStudentSelect.lastChild);
            }
            
            // Add student options
            students.forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.textContent = student.name;
                gradeStudentSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to setup grade entry form:', error);
    }
}

// Handle grade entry form submission
async function handleGradeEntry(event) {
    event.preventDefault();
    
    const studentId = parseInt(document.getElementById('grade-student').value);
    const subject = document.getElementById('grade-subject').value.trim();
    const score = parseInt(document.getElementById('grade-score').value);
    const gradeType = document.getElementById('grade-type').value;
    const term = document.getElementById('grade-term').value.trim();
    const comments = document.getElementById('grade-comments').value.trim() || 'No comments provided';
    
    if (!studentId || !subject || !score || !gradeType || !term) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    if (score < 0 || score > 100) {
        showNotification('Score must be between 0 and 100', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        const user = authManager.getCurrentUser();
        
        // Calculate grade letter
        let grade = 'F';
        if (score >= 90) grade = 'A';
        else if (score >= 80) grade = 'B';
        else if (score >= 70) grade = 'C';
        else if (score >= 60) grade = 'D';
        
        const gradeData = {
            studentId: studentId,
            teacherId: user.id,
            teacherName: user.name,
            subject: subject,
            score: score,
            maxScore: 100, // Default max score
            grade: grade,
            gradeType: gradeType,
            term: term,
            comments: comments,
            dateCreated: new Date().toISOString(),
            lastModified: new Date().toISOString()
        };
        
        await visionDB.addGrade(gradeData);
        
        showNotification(`Grade added successfully for ${subject}!`, 'success');
        document.getElementById('grade-entry-form').reset();
        
        // Refresh students list to show updated grades
        await loadStudentsList();
        
        showLoading(false);
    } catch (error) {
        console.error('Failed to add grade:', error);
        showNotification('Failed to add grade', 'error');
        showLoading(false);
    }
}

// View detailed grades for a specific student
async function viewStudentGrades(studentId) {
    try {
        const allGrades = await visionDB.getAllGrades();
        const studentGrades = allGrades.filter(grade => grade.studentId === studentId);
        const users = await visionDB.getAllUsers();
        const student = users.find(user => user.id === studentId);
        
        if (!student) {
            showNotification('Student not found', 'error');
            return;
        }
        
        let gradesHTML = `
            <div class="student-grades-modal">
                <h2>📊 Grades for ${student.name}</h2>
                <p>Student ID: ${student.studentId || student.id}</p>
        `;
        
        if (studentGrades.length === 0) {
            gradesHTML += '<p class="no-grades">No grades recorded for this student yet.</p>';
        } else {
            // Calculate overall performance
            let totalScore = 0;
            let totalMax = 0;
            studentGrades.forEach(grade => {
                totalScore += grade.score;
                totalMax += grade.maxScore;
            });
            
            const average = Math.round((totalScore / totalMax) * 100);
            let overallGrade = 'F';
            if (average >= 90) overallGrade = 'A';
            else if (average >= 80) overallGrade = 'B';
            else if (average >= 70) overallGrade = 'C';
            else if (average >= 60) overallGrade = 'D';
            
            gradesHTML += `
                <div class="overall-performance">
                    <h3>Overall Performance</h3>
                    <p>Average: ${average}% | Grade: <span class="grade-${overallGrade.toLowerCase()}">${overallGrade}</span></p>
                    <p>Total Subjects: ${studentGrades.length}</p>
                </div>
                <div class="grades-breakdown">
                    <h3>Subject Breakdown</h3>
            `;
            
            studentGrades.forEach(grade => {
                gradesHTML += `
                    <div class="grade-item">
                        <h4>${grade.subject}</h4>
                        <div class="grade-details">
                            <span class="score">${grade.score}/${grade.maxScore} (${Math.round((grade.score/grade.maxScore)*100)}%)</span>
                            <span class="grade-badge grade-${grade.grade.toLowerCase()}">${grade.grade}</span>
                        </div>
                        <p><strong>Type:</strong> ${grade.gradeType}</p>
                        <p><strong>Term:</strong> ${grade.term}</p>
                        <p><strong>Comments:</strong> ${grade.comments}</p>
                        <p class="date">Graded: ${new Date(grade.dateCreated).toLocaleDateString()}</p>
                    </div>
                `;
            });
            
            gradesHTML += '</div>';
        }
        
        gradesHTML += '</div>';
        
        // Show in a modal
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content student-grades-content">
                <div class="modal-header">
                    <h2>Student Grades</h2>
                    <button class="modal-close" onclick="closeModal()">×</button>
                </div>
                <div class="modal-body">
                    ${gradesHTML}
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal();
            }
        });
        
    } catch (error) {
        console.error('Failed to load student grades:', error);
        showNotification('Failed to load student grades', 'error');
    }
}

// Service Worker Registration
if ('serviceWorker' in navigator) {
    window.addEventListener('load', async () => {
        try {
            const registration = await navigator.serviceWorker.register('service-worker.js');
            console.log('Service Worker registered:', registration);
        } catch (error) {
            console.error('Service Worker registration failed:', error);
        }
    });
}
