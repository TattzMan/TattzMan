// Authentication System for Vision College PWA
class AuthManager {
    constructor() {
        this.currentUser = null;
        this.currentSession = null;
    }

    // Initialize authentication system
    async init() {
        try {
            // Check for existing session
            const session = await visionDB.getCurrentSession();
            if (session) {
                this.currentSession = session;
                this.currentUser = session;
                console.log('Restored session for:', session.username);
                return session;
            }
            return null;
        } catch (error) {
            console.error('Failed to initialize auth:', error);
            return null;
        }
    }

    // Login with username and password
    async login(username, password, role = null) {
        try {
            showLoading(true);
            
            const user = await visionDB.authenticateUser(username, password);
            
            // Verify role if specified
            if (role && user.role !== role) {
                throw new Error(`Access denied. User is not a ${role}.`);
            }

            this.currentUser = user;
            this.currentSession = await visionDB.getCurrentSession();
            
            console.log('Login successful:', user.username);
            showLoading(false);
            
            return user;
        } catch (error) {
            showLoading(false);
            console.error('Login failed:', error);
            throw error;
        }
    }

    // USSD-style login
    async ussdLogin(password) {
        try {
            showLoading(true);
            console.log('Attempting USSD login with password:', password);
            
            // For USSD, try all possible users with this password
            const usernames = ['student1', 'teacher1', 'admin'];
            let user = null;
            
            for (let username of usernames) {
                try {
                    console.log(`Trying login with username: ${username}`);
                    user = await visionDB.authenticateUser(username, password);
                    if (user) {
                        console.log(`USSD login successful with ${username}`);
                        break;
                    }
                } catch (error) {
                    console.log(`Login failed for ${username}:`, error.message);
                    // Continue to next username
                }
            }

            if (!user) {
                throw new Error('Invalid USSD password. Please check your password and try again.');
            }

            this.currentUser = user;
            this.currentSession = await visionDB.getCurrentSession();
            
            console.log('USSD login successful:', user.username, user.role);
            showLoading(false);
            
            return user;
        } catch (error) {
            showLoading(false);
            console.error('USSD login failed:', error);
            throw error;
        }
    }

    // Logout
    async logout() {
        try {
            await visionDB.clearSession();
            this.currentUser = null;
            this.currentSession = null;
            console.log('Logout successful');
            return true;
        } catch (error) {
            console.error('Logout failed:', error);
            throw error;
        }
    }

    // Check if user is authenticated
    isAuthenticated() {
        return this.currentUser !== null;
    }

    // Check if user has specific role
    hasRole(role) {
        return this.currentUser && this.currentUser.role === role;
    }

    // Get current user info
    getCurrentUser() {
        return this.currentUser;
    }

    // Get current session info
    getCurrentSession() {
        return this.currentSession;
    }

    // Update last activity
    async updateActivity() {
        if (this.currentSession) {
            try {
                const sessionData = {
                    ...this.currentSession,
                    lastActivity: new Date().toISOString()
                };
                await visionDB.createSession(this.currentUser.id, this.currentUser);
                this.currentSession = sessionData;
            } catch (error) {
                console.error('Failed to update activity:', error);
            }
        }
    }

    // Register new user (for future use)
    async register(userData) {
        try {
            showLoading(true);
            
            // Add timestamp
            userData.dateCreated = new Date().toISOString();
            
            const userId = await visionDB.addUser(userData);
            console.log('User registered successfully:', userId);
            
            showLoading(false);
            return userId;
        } catch (error) {
            showLoading(false);
            console.error('Registration failed:', error);
            throw error;
        }
    }

    // Change password (for future use)
    async changePassword(oldPassword, newPassword) {
        try {
            if (!this.currentUser) {
                throw new Error('User not authenticated');
            }

            // Verify old password
            if (this.currentUser.password !== oldPassword) {
                throw new Error('Current password is incorrect');
            }

            // Update password in database
            await visionDB.updateUser(this.currentUser.id, { password: newPassword });
            
            this.currentUser.password = newPassword;
            console.log('Password changed successfully');
            
            return true;
        } catch (error) {
            console.error('Password change failed:', error);
            throw error;
        }
    }
}

// Authentication Functions for UI

// Handle web login form submission
async function handleWebLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    if (!username || !password || !role) {
        showNotification('Please fill in all fields', 'error');
        return;
    }

    try {
        const user = await authManager.login(username, password, role);
        showNotification(`Welcome, ${user.name}!`, 'success');
        
        // Redirect to appropriate dashboard
        if (user.role === 'student') {
            showStudentDashboard(user);
        } else if (user.role === 'teacher') {
            showTeacherDashboard(user);
        }
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// Handle USSD dial
function handleUSSDDial() {
    const dialInput = document.getElementById('ussd-dial');
    const dialValue = dialInput.value.trim();

    if (dialValue === '*123#') {
        // Show password step
        document.getElementById('ussd-welcome').classList.remove('active');
        document.getElementById('ussd-password').classList.add('active');
        
        // Focus on password input
        setTimeout(() => {
            document.getElementById('ussd-pass').focus();
        }, 100);
    } else {
        showNotification('Invalid USSD code. Please dial *123#', 'error');
        dialInput.value = '';
    }
}

// Handle USSD password
async function handleUSSDPassword() {
    const password = document.getElementById('ussd-pass').value.trim();

    if (!password) {
        showNotification('Please enter your password', 'error');
        return;
    }

    console.log('USSD password entered:', password);
    
    try {
        // Add small delay to ensure database is ready
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const user = await authManager.ussdLogin(password);
        showNotification(`USSD Login successful! Welcome, ${user.name}`, 'success');
        
        // Show menu options
        document.getElementById('ussd-password').classList.remove('active');
        document.getElementById('ussd-menu').classList.add('active');
    } catch (error) {
        console.error('USSD password error:', error);
        showNotification(error.message, 'error');
        document.getElementById('ussd-pass').value = '';
    }
}

// Go back to USSD welcome
function backToUSSDWelcome() {
    document.getElementById('ussd-password').classList.remove('active');
    document.getElementById('ussd-menu').classList.remove('active');
    document.getElementById('ussd-welcome').classList.add('active');
    
    // Clear inputs
    document.getElementById('ussd-dial').value = '';
    document.getElementById('ussd-pass').value = '';
}

// Open dashboard from USSD menu
function openDashboard(type) {
    const user = authManager.getCurrentUser();
    
    if (!user) {
        showNotification('Please login first', 'error');
        return;
    }

    if (type === 'student' && user.role === 'student') {
        showStudentDashboard(user);
    } else if (type === 'teacher' && user.role === 'teacher') {
        showTeacherDashboard(user);
    } else {
        showNotification(`Access denied. You don't have ${type} privileges.`, 'error');
    }
}

// Show student dashboard
function showStudentDashboard(user) {
    hideAllScreens();
    document.getElementById('student-dashboard').classList.add('active');
    document.getElementById('student-name').textContent = `Welcome, ${user.name}`;
    
    // Load student content
    loadStudentResults();
    loadStudentGrades();
    loadStudentNotes();
    loadStudentSyllabus();
    loadStudentProfile();
}

// Show teacher dashboard
function showTeacherDashboard(user) {
    hideAllScreens();
    document.getElementById('teacher-dashboard').classList.add('active');
    document.getElementById('teacher-name').textContent = `Welcome, ${user.name}`;
    
    // Load teacher content
    loadTeacherContent();
    loadStudentsList();
    loadTeacherProfile();
}

// Logout function
async function logout() {
    try {
        await authManager.logout();
        showNotification('Logged out successfully', 'info');
        
        // Reset to initial state
        showUSSD();
        
        // Clear forms
        document.getElementById('login-form').reset();
        backToUSSDWelcome();
    } catch (error) {
        showNotification('Logout failed', 'error');
    }
}

// Show web login
function showWebLogin() {
    hideAllScreens();
    document.getElementById('web-login').classList.add('active');
}

// Show USSD interface
function showUSSD() {
    hideAllScreens();
    const ussdInterface = document.getElementById('ussd-interface');
    if (ussdInterface) {
        ussdInterface.classList.add('active');
        backToUSSDWelcome();
    } else {
        console.warn('USSD interface not found; falling back to web login.');
        showWebLogin();
    }
}

// Hide all screens
function hideAllScreens() {
    const screens = document.querySelectorAll('.screen');
    screens.forEach(screen => screen.classList.remove('active'));
}

// Show loading indicator
function showLoading(show) {
    const loading = document.getElementById('loading');
    if (show) {
        loading.classList.add('show');
    } else {
        loading.classList.remove('show');
    }
}

// Show notification
function showNotification(message, type = 'info') {
    visionDB.showNotification(message, type);
}

// Initialize auth manager
const authManager = new AuthManager();
