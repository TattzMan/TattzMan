// Vision College Database - IndexedDB Implementation
class VisionCollegeDB {
    constructor() {
        this.dbName = 'VisionCollegeDB';
        this.version = 1;
        this.db = null;
        this.isOnline = navigator.onLine;
        
        // Listen for online/offline events
        window.addEventListener('online', () => {
            this.isOnline = true;
            this.updateOnlineStatus();
            this.syncData();
        });
        
        window.addEventListener('offline', () => {
            this.isOnline = false;
            this.updateOnlineStatus();
        });
    }

    // Initialize database
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.version);
            
            request.onerror = () => {
                console.error('Database failed to open');
                reject(request.error);
            };
            
            request.onsuccess = async () => {
                this.db = request.result;
                console.log('Database opened successfully');
                
                // Check if we need to add default users
                try {
                    const userCount = await this.getUserCount();
                    if (userCount === 0) {
                        console.log('Adding default users and content...');
                        await this.addDefaultUsers();
                    }
                } catch (error) {
                    console.error('Error checking/adding default users:', error);
                }
                
                resolve(this.db);
            };
            
            request.onupgradeneeded = (event) => {
                this.db = event.target.result;
                this.setupStores();
            };
        });
    }

    // Setup object stores
    setupStores() {
        // Users store
        if (!this.db.objectStoreNames.contains('users')) {
            const usersStore = this.db.createObjectStore('users', { keyPath: 'id', autoIncrement: true });
            usersStore.createIndex('username', 'username', { unique: true });
            usersStore.createIndex('role', 'role', { unique: false });
        }

        // Notes store
        if (!this.db.objectStoreNames.contains('notes')) {
            const notesStore = this.db.createObjectStore('notes', { keyPath: 'id', autoIncrement: true });
            notesStore.createIndex('subject', 'subject', { unique: false });
            notesStore.createIndex('teacherId', 'teacherId', { unique: false });
            notesStore.createIndex('dateCreated', 'dateCreated', { unique: false });
        }

        // Syllabus store
        if (!this.db.objectStoreNames.contains('syllabus')) {
            const syllabusStore = this.db.createObjectStore('syllabus', { keyPath: 'id', autoIncrement: true });
            syllabusStore.createIndex('subject', 'subject', { unique: false });
            syllabusStore.createIndex('teacherId', 'teacherId', { unique: false });
            syllabusStore.createIndex('dateCreated', 'dateCreated', { unique: false });
        }

        // Sync queue for offline operations
        if (!this.db.objectStoreNames.contains('syncQueue')) {
            const syncStore = this.db.createObjectStore('syncQueue', { keyPath: 'id', autoIncrement: true });
            syncStore.createIndex('type', 'type', { unique: false });
            syncStore.createIndex('timestamp', 'timestamp', { unique: false });
        }

        // User sessions
        if (!this.db.objectStoreNames.contains('sessions')) {
            const sessionsStore = this.db.createObjectStore('sessions', { keyPath: 'id' });
            sessionsStore.createIndex('userId', 'userId', { unique: false });
        }

        // Grades store
        if (!this.db.objectStoreNames.contains('grades')) {
            const gradesStore = this.db.createObjectStore('grades', { keyPath: 'id', autoIncrement: true });
            gradesStore.createIndex('studentId', 'studentId', { unique: false });
            gradesStore.createIndex('subject', 'subject', { unique: false });
            gradesStore.createIndex('term', 'term', { unique: false });
        }
    }

    // Add default users for testing
    async addDefaultUsers() {
        const defaultUsers = [
            {
                username: 'student1',
                password: 'password123',
                role: 'student',
                name: 'Tatenda',
                email: 'tatenda@visioncollege.edu',
                studentId: 'VC2024001',
                dateCreated: new Date().toISOString()
            },
            {
                username: 'teacher1',
                password: 'teacher123',
                role: 'teacher',
                name: 'Mr. Nyamande',
                email: 'nyamande@visioncollege.edu',
                teacherId: 'TCH001',
                subjects: ['Mathematics', 'Physics', 'Chemistry', 'Biology'],
                dateCreated: new Date().toISOString()
            },
            {
                username: 'admin',
                password: 'admin123',
                role: 'teacher',
                name: 'Admin User',
                email: 'admin@visioncollege.edu',
                teacherId: 'ADM001',
                subjects: ['Administration'],
                dateCreated: new Date().toISOString()
            }
        ];

        for (let user of defaultUsers) {
            await this.addUser(user);
        }
        
        // Add sample content and grades
        await this.addSampleContent();
        await this.addStudentGrades();
    }

    // Add sample content
    async addSampleContent() {
        const sampleNotes = [
            {
                title: 'Introduction to Mathematics',
                subject: 'Mathematics',
                content: 'This note covers the basic principles of mathematics including algebra, geometry, and calculus fundamentals.',
                teacherId: 2,
                teacherName: 'Prof. Jane Smith',
                dateCreated: new Date().toISOString(),
                lastModified: new Date().toISOString(),
                isOfflineAvailable: true
            },
            {
                title: 'Physics - Newton\'s Laws',
                subject: 'Physics',
                content: 'Understanding the three laws of motion by Sir Isaac Newton and their applications in real-world scenarios.',
                teacherId: 2,
                teacherName: 'Prof. Jane Smith',
                dateCreated: new Date().toISOString(),
                lastModified: new Date().toISOString(),
                isOfflineAvailable: true
            }
        ];

        const sampleSyllabus = [
            {
                title: 'Mathematics Course Syllabus 2024',
                subject: 'Mathematics',
                content: 'Course Outline:\n1. Algebra fundamentals\n2. Geometry principles\n3. Introduction to calculus\n4. Statistics basics\n5. Final examination',
                teacherId: 2,
                teacherName: 'Prof. Jane Smith',
                dateCreated: new Date().toISOString(),
                lastModified: new Date().toISOString(),
                isOfflineAvailable: true
            },
            {
                title: 'Physics Course Syllabus 2024',
                subject: 'Physics',
                content: 'Course Outline:\n1. Mechanics\n2. Thermodynamics\n3. Electromagnetism\n4. Modern physics\n5. Laboratory work\n6. Final project',
                teacherId: 2,
                teacherName: 'Prof. Jane Smith',
                dateCreated: new Date().toISOString(),
                lastModified: new Date().toISOString(),
                isOfflineAvailable: true
            }
        ];

        for (let note of sampleNotes) {
            await this.addNote(note);
        }

        for (let syllabus of sampleSyllabus) {
            await this.addSyllabus(syllabus);
        }
    }

    // Add student grades
    async addStudentGrades() {
        const grades = [
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Mathematics',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'A',
                score: 92,
                maxScore: 100,
                comments: 'Excellent performance in algebra and geometry',
                dateRecorded: new Date().toISOString()
            },
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Physics',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'B+',
                score: 85,
                maxScore: 100,
                comments: 'Good understanding of mechanics and thermodynamics',
                dateRecorded: new Date().toISOString()
            },
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Chemistry',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'A-',
                score: 88,
                maxScore: 100,
                comments: 'Strong performance in organic chemistry',
                dateRecorded: new Date().toISOString()
            },
            {
                studentId: 1,
                studentName: 'Tatenda',
                subject: 'Biology',
                teacherName: 'Mr. Nyamande',
                term: 'Term 3 2024',
                grade: 'A',
                score: 91,
                maxScore: 100,
                comments: 'Excellent work in molecular biology and genetics',
                dateRecorded: new Date().toISOString()
            }
        ];

        for (let grade of grades) {
            await this.addGrade(grade);
        }
    }

    // Grades management
    async addGrade(gradeData) {
        return this.performTransaction('grades', 'readwrite', (store, resolve, reject) => {
            const request = store.add(gradeData);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getStudentGrades(studentId) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['grades'], 'readonly');
            const store = transaction.objectStore('grades');
            const index = store.index('studentId');
            
            const request = index.getAll(studentId);
            
            request.onsuccess = () => {
                resolve(request.result || []);
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    // Generic database operations
    async performTransaction(storeName, mode, operation) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], mode);
            const store = transaction.objectStore(storeName);
            
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
            
            operation(store, resolve, reject);
        });
    }

    // Get user count
    async getUserCount() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['users'], 'readonly');
            const store = transaction.objectStore('users');
            const request = store.count();
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // User management
    async addUser(userData) {
        return this.performTransaction('users', 'readwrite', (store, resolve, reject) => {
            const request = store.add(userData);
            request.onsuccess = () => {
                console.log('Added user:', userData.username);
                resolve(request.result);
            };
            request.onerror = () => {
                // Ignore duplicate key errors for default users
                if (request.error.name === 'ConstraintError') {
                    console.log('User already exists:', userData.username);
                    resolve(null);
                } else {
                    reject(request.error);
                }
            };
        });
    }

    async authenticateUser(username, password) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['users'], 'readonly');
            const store = transaction.objectStore('users');
            const index = store.index('username');
            
            const request = index.get(username);
            
            request.onsuccess = () => {
                const user = request.result;
                if (user && user.password === password) {
                    // Create session
                    this.createSession(user.id, user);
                    resolve(user);
                } else {
                    reject(new Error('Invalid credentials'));
                }
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    async createSession(userId, userData) {
        const sessionData = {
            id: 'current_session',
            userId: userId,
            username: userData.username,
            role: userData.role,
            name: userData.name,
            loginTime: new Date().toISOString(),
            lastActivity: new Date().toISOString()
        };

        return this.performTransaction('sessions', 'readwrite', (store, resolve, reject) => {
            const request = store.put(sessionData);
            request.onsuccess = () => resolve(sessionData);
            request.onerror = () => reject(request.error);
        });
    }

    async getCurrentSession() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['sessions'], 'readonly');
            const store = transaction.objectStore('sessions');
            
            const request = store.get('current_session');
            
            request.onsuccess = () => {
                resolve(request.result || null);
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    async clearSession() {
        return this.performTransaction('sessions', 'readwrite', (store, resolve, reject) => {
            const request = store.delete('current_session');
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // Notes management
    async addNote(noteData) {
        // Add to sync queue if offline
        if (!this.isOnline) {
            await this.addToSyncQueue('add_note', noteData);
        }

        return this.performTransaction('notes', 'readwrite', (store, resolve, reject) => {
            const request = store.add(noteData);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getNotes() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['notes'], 'readonly');
            const store = transaction.objectStore('notes');
            
            const request = store.getAll();
            
            request.onsuccess = () => {
                resolve(request.result || []);
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    async updateNote(id, noteData) {
        if (!this.isOnline) {
            await this.addToSyncQueue('update_note', { id, ...noteData });
        }

        return this.performTransaction('notes', 'readwrite', (store, resolve, reject) => {
            const getRequest = store.get(id);
            getRequest.onsuccess = () => {
                const existingNote = getRequest.result;
                if (existingNote) {
                    const updatedNote = { ...existingNote, ...noteData, lastModified: new Date().toISOString() };
                    const putRequest = store.put(updatedNote);
                    putRequest.onsuccess = () => resolve(putRequest.result);
                    putRequest.onerror = () => reject(putRequest.error);
                } else {
                    reject(new Error('Note not found'));
                }
            };
        });
    }

    async deleteNote(id) {
        if (!this.isOnline) {
            await this.addToSyncQueue('delete_note', { id });
        }

        return this.performTransaction('notes', 'readwrite', (store, resolve, reject) => {
            const request = store.delete(id);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // Syllabus management
    async addSyllabus(syllabusData) {
        if (!this.isOnline) {
            await this.addToSyncQueue('add_syllabus', syllabusData);
        }

        return this.performTransaction('syllabus', 'readwrite', (store, resolve, reject) => {
            const request = store.add(syllabusData);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getSyllabus() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['syllabus'], 'readonly');
            const store = transaction.objectStore('syllabus');
            
            const request = store.getAll();
            
            request.onsuccess = () => {
                resolve(request.result || []);
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    async updateSyllabus(id, syllabusData) {
        if (!this.isOnline) {
            await this.addToSyncQueue('update_syllabus', { id, ...syllabusData });
        }

        return this.performTransaction('syllabus', 'readwrite', (store, resolve, reject) => {
            const getRequest = store.get(id);
            getRequest.onsuccess = () => {
                const existingSyllabus = getRequest.result;
                if (existingSyllabus) {
                    const updatedSyllabus = { ...existingSyllabus, ...syllabusData, lastModified: new Date().toISOString() };
                    const putRequest = store.put(updatedSyllabus);
                    putRequest.onsuccess = () => resolve(putRequest.result);
                    putRequest.onerror = () => reject(putRequest.error);
                } else {
                    reject(new Error('Syllabus not found'));
                }
            };
        });
    }

    async deleteSyllabus(id) {
        if (!this.isOnline) {
            await this.addToSyncQueue('delete_syllabus', { id });
        }

        return this.performTransaction('syllabus', 'readwrite', (store, resolve, reject) => {
            const request = store.delete(id);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // Sync queue management for offline operations
    async addToSyncQueue(type, data) {
        const syncItem = {
            type: type,
            data: data,
            timestamp: new Date().toISOString(),
            synced: false
        };

        return this.performTransaction('syncQueue', 'readwrite', (store, resolve, reject) => {
            const request = store.add(syncItem);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getSyncQueue() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['syncQueue'], 'readonly');
            const store = transaction.objectStore('syncQueue');
            
            const request = store.getAll();
            
            request.onsuccess = () => {
                resolve(request.result || []);
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    async clearSyncQueue() {
        return this.performTransaction('syncQueue', 'readwrite', (store, resolve, reject) => {
            const request = store.clear();
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    // Sync data when coming back online
    async syncData() {
        try {
            this.updateSyncStatus('syncing');
            const syncQueue = await this.getSyncQueue();
            console.log(`Syncing ${syncQueue.length} items...`);

            if (syncQueue.length === 0) {
                this.updateSyncStatus('success');
                console.log('No items to sync');
                return;
            }

            let successCount = 0;
            let errorCount = 0;

            for (let item of syncQueue) {
                try {
                    // Simulate server sync with better error handling
                    await this.syncItem(item);
                    successCount++;
                    console.log(`✅ Synced ${item.type}:`, item.data.title || item.data.name || 'item');
                } catch (error) {
                    errorCount++;
                    console.error(`❌ Failed to sync item ${item.id}:`, error);
                    // Don't break the loop, continue with other items
                }
            }

            // Clear successfully synced items
            if (successCount > 0) {
                await this.clearSyncQueue();
            }

            // Update sync status and show notification
            if (errorCount === 0) {
                this.updateSyncStatus('success');
                this.showNotification(`✅ ${successCount} items synchronized successfully!`, 'success');
            } else if (successCount > 0) {
                this.updateSyncStatus('partial');
                this.showNotification(`⚠️ Partial sync: ${successCount} succeeded, ${errorCount} failed`, 'warning');
            } else {
                this.updateSyncStatus('error');
                this.showNotification(`❌ Sync failed: ${errorCount} items couldn't be synchronized`, 'error');
            }
            
            console.log(`Sync completed: ${successCount} successful, ${errorCount} failed`);
        } catch (error) {
            this.updateSyncStatus('error');
            console.error('Sync operation failed:', error);
            this.showNotification('❌ Synchronization failed. Will retry later.', 'error');
        }
    }

    // Update online status indicators
    updateOnlineStatus() {
        const indicators = [
            document.getElementById('notes-offline-status'),
            document.getElementById('syllabus-offline-status'),
            document.getElementById('results-offline-status'),
            document.getElementById('grades-offline-status')
        ];

        const statusText = this.isOnline ? '🟢 Online' : '🔴 Offline';
        indicators.forEach(indicator => {
            if (indicator) {
                indicator.textContent = statusText;
                indicator.className = this.isOnline ? 'online' : 'offline';
            }
        });

        const notification = document.getElementById('offline-notification');
        if (notification) {
            if (this.isOnline) {
                notification.classList.remove('show');
                // Auto-sync when coming online
                setTimeout(() => this.syncData(), 1000);
            } else {
                notification.classList.add('show');
            }
        }
    }

    // Show notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = 'notification show';
        notification.innerHTML = `<p>${message}</p>`;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    // Search functionality
    async searchNotes(query) {
        const notes = await this.getNotes();
        return notes.filter(note => 
            note.title.toLowerCase().includes(query.toLowerCase()) ||
            note.content.toLowerCase().includes(query.toLowerCase()) ||
            note.subject.toLowerCase().includes(query.toLowerCase())
        );
    }

    async searchSyllabus(query) {
        const syllabus = await this.getSyllabus();
        return syllabus.filter(item => 
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.content.toLowerCase().includes(query.toLowerCase()) ||
            item.subject.toLowerCase().includes(query.toLowerCase())
        );
    }

    // Get content by subject
    async getNotesBySubject(subject) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['notes'], 'readonly');
            const store = transaction.objectStore('notes');
            const index = store.index('subject');
            
            const request = index.getAll(subject);
            
            request.onsuccess = () => {
                resolve(request.result || []);
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    async getSyllabusBySubject(subject) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['syllabus'], 'readonly');
            const store = transaction.objectStore('syllabus');
            const index = store.index('subject');
            
            const request = index.getAll(subject);
            
            request.onsuccess = () => {
                resolve(request.result || []);
            };
            
            request.onerror = () => reject(request.error);
        });
    }

    // Get all users
    async getAllUsers() {
        try {
            const transaction = this.db.transaction(['users'], 'readonly');
            const store = transaction.objectStore('users');
            const request = store.getAll();
            
            return new Promise((resolve, reject) => {
                request.onsuccess = () => resolve(request.result || []);
                request.onerror = () => reject(request.error);
            });
        } catch (error) {
            console.error('Failed to get all users:', error);
            return [];
        }
    }

    // Get all grades
    async getAllGrades() {
        try {
            const transaction = this.db.transaction(['grades'], 'readonly');
            const store = transaction.objectStore('grades');
            const request = store.getAll();
            
            return new Promise((resolve, reject) => {
                request.onsuccess = () => resolve(request.result || []);
                request.onerror = () => reject(request.error);
            });
        } catch (error) {
            console.error('Failed to get all grades:', error);
            return [];
        }
    }

    // Sync a single item (simulated server sync)
    async syncItem(item) {
        return new Promise((resolve, reject) => {
            // Simulate network delay and occasional failures
            const delay = Math.random() * 1000 + 500; // 500-1500ms delay
            const failureRate = 0.1; // 10% chance of failure
            
            setTimeout(() => {
                if (Math.random() < failureRate) {
                    reject(new Error(`Network error syncing ${item.type}`));
                } else {
                    console.log(`Server accepted ${item.type}:`, item.data.title || item.data.name || 'data');
                    resolve({ success: true, item: item });
                }
            }, delay);
        });
    }

    // Update sync status indicators
    updateSyncStatus(status) {
        const syncIndicators = document.querySelectorAll('.sync-status');
        
        syncIndicators.forEach(indicator => {
            if (indicator) {
                switch (status) {
                    case 'syncing':
                        indicator.textContent = '🔄 Syncing...';
                        indicator.className = 'sync-status syncing';
                        break;
                    case 'success':
                        indicator.textContent = '✅ Synced';
                        indicator.className = 'sync-status success';
                        // Hide success message after 3 seconds
                        setTimeout(() => {
                            if (indicator.textContent === '✅ Synced') {
                                indicator.textContent = '🟢 Online';
                                indicator.className = 'sync-status online';
                            }
                        }, 3000);
                        break;
                    case 'error':
                        indicator.textContent = '❌ Sync Failed';
                        indicator.className = 'sync-status error';
                        break;
                    case 'partial':
                        indicator.textContent = '⚠️ Partial Sync';
                        indicator.className = 'sync-status warning';
                        break;
                }
            }
        });

        // Update main sync status in header if present
        const mainSyncStatus = document.getElementById('main-sync-status');
        if (mainSyncStatus) {
            mainSyncStatus.className = `sync-indicator ${status}`;
            mainSyncStatus.textContent = this.getSyncStatusText(status);
        }
    }

    // Get sync status text
    getSyncStatusText(status) {
        switch (status) {
            case 'syncing': return '🔄 Syncing';
            case 'success': return '✅ Synced';
            case 'error': return '❌ Error';
            case 'partial': return '⚠️ Partial';
            default: return '🟢 Online';
        }
    }

    // Force sync manually
    async forcSync() {
        if (!this.isOnline) {
            this.showNotification('❌ Cannot sync while offline', 'error');
            return;
        }
        
        this.showNotification('🔄 Starting manual sync...', 'info');
        await this.syncData();
    }
}

// Initialize database instance
const visionDB = new VisionCollegeDB();
