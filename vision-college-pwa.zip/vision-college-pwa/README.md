# Vision College PWA

A Progressive Web Application (PWA) for Vision College Learning Management System with USSD access and offline functionality.

## Quick Start (run in your browser)

### Requirements
- A modern browser (Chrome/Edge recommended)
- One of: Node.js (for `npx serve`) or Python (for `py -m http.server`) or VS Code Live Server

### Start a local server (pick one)
- Node:
  1) Open PowerShell in the project folder
  2) Run: `npx serve -l 8080`
  3) Open: `http://localhost:8080/`

- Python:
  1) Open PowerShell in the project folder
  2) Run: `py -m http.server 8080`
  3) Open: `http://localhost:8080/`

- VS Code Live Server:
  1) Open the folder in VS Code
  2) Install “Live Server” extension
  3) Right‑click `index.html` → “Open with Live Server”

Why a server? PWAs and service workers must be served over HTTP/HTTPS. Opening `index.html` directly from disk will break caching and some features.

## Features

- **Progressive Web App**: Installable on mobile and desktop devices
- **USSD Interface**: Dial *123# to access the system via USSD-style interface
- **Offline Support**: Works offline like TikTok, caching content for offline viewing
- **Role-Based Access**: Separate dashboards for students and teachers
- **IndexedDB Database**: Client-side database for offline data persistence
- **Service Worker**: Enables caching and background sync
- **Responsive Design**: Works on all screen sizes

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Database**: IndexedDB for client-side storage
- **PWA Features**: Service Worker, Web App Manifest
- **Offline Storage**: Cache API + IndexedDB
- **Authentication**: Local authentication with role-based access

## Database Choice Explanation

For your requirements, **IndexedDB** is the perfect choice because:

1. **Online/Offline Support**: Works seamlessly whether online or offline
2. **Large Storage**: Can store substantial amounts of data (notes, syllabus, files)
3. **TikTok-like Behavior**: Caches content for offline viewing like TikTok caches videos
4. **No Server Required**: Runs completely in the browser
5. **Structured Data**: Supports complex queries and indexing
6. **Background Sync**: Can sync data when connection is restored

## Getting Started

### 1. Setup

1) Extract or clone the project
2) Start a local server (see Quick Start above)
3) Open the site in your browser

### 2. Login Credentials

The system comes with pre-configured test users:

#### USSD Access (*123#)
- **Student Password**: `password123`
- **Teacher Password**: `teacher123`
- **Admin Password**: `admin123`

#### Web Login
**Student Account:**
- Username: `student1`
- Password: `password123`
- Role: Student

**Teacher Account:**
- Username: `teacher1`
- Password: `teacher123`
- Role: Teacher

**Admin Account:**
- Username: `admin`
- Password: `admin123`
- Role: Teacher

### 3. How to Use

#### USSD Access
1. Open the application
2. Enter `*123#` in the USSD dial field
3. Click "Dial"
4. Enter one of the passwords above
5. Select your role from the menu

#### Web Login
1. Click "🌐 Web Login" (or it may open by default if USSD UI isn’t present)
2. Enter username, password, and select role
3. Click "Login"

## Features Walkthrough

### Student Features
- **📚 Notes**: View course notes with offline access
- **📋 Syllabus**: Access course syllabus documents
- **👤 Profile**: View student information
- **🔴 Offline Mode**: Access previously viewed content offline

### Teacher Features
- **📤 Upload**: Create and upload notes and syllabus
- **📁 Manage**: Edit and delete your content
- **👥 Students**: Student management (placeholder for future features)
- **👤 Profile**: View teacher information

### Offline Functionality
- Content is automatically cached when viewed
- Works offline similar to TikTok's video caching
- Online/offline status indicators
- Background sync when connection is restored
- Service worker handles caching strategy

Tips:
- To install as an app, use your browser’s “Install” option (address bar icon in Chrome/Edge).
- If you deploy a new version and don’t see changes, do a hard refresh: Ctrl+F5 (Windows) or clear site data (see Troubleshooting).

## Project Structure

```
vision-college-pwa/
├── index.html              # Main application file
├── manifest.json          # PWA manifest
├── service-worker.js      # Service worker for offline functionality
├── offline.html           # Offline fallback page
├── css/
│   └── styles.css         # Application styles
├── js/
│   ├── app.js            # Main application logic
│   ├── auth.js           # Authentication system
│   └── database.js       # IndexedDB database implementation
├── icons/                 # PWA icons (add your own)
└── README.md             # This file
```

## Adding Icons

To complete the PWA setup, add the following icon sizes to the `icons/` folder:
- icon-72x72.png
- icon-96x96.png
- icon-128x128.png
- icon-144x144.png
- icon-152x152.png
- icon-192x192.png
- icon-384x384.png
- icon-512x512.png

You can use online tools like [PWA Icon Generator](https://www.pwabuilder.com/imageGenerator) to create these from a single image.

Note: If icons are missing, the browser/console may show 404s like `icons/icon-144x144.png 404`. These are harmless for local testing. Add the files later for a complete PWA install experience.

## Development

### Testing Offline Functionality
1. Open Chrome DevTools (F12)
2. Go to Network tab
3. Check "Offline" checkbox
4. Refresh the page to test offline mode

### Installing as PWA
1. Open the app in Chrome
2. Click the install button in the address bar
3. Or go to Settings > Install Vision College

## Future Enhancements

- File upload/download functionality
- Real-time notifications
- Assignment submissions
- Grade tracking
- Communication features
- Server-side API integration
- Real USSD gateway integration

## Browser Compatibility

- Chrome/Chromium: Full support
- Firefox: Full support (except background sync)
- Safari: Partial support (no background sync)
- Edge: Full support

## Support

For any issues or questions:
1. Check browser console for error messages
2. Ensure you're using a compatible browser
3. Try clearing browser data and reloading

## License

This project is created for educational purposes. Feel free to modify and extend as needed.

---

**Vision College** - Empowering education through technology 🎓📱

---

## Troubleshooting (common issues)

- **Failed to initialize application**
  - Ensure you’re serving via a local server (see Quick Start). Do not double‑click `index.html` from disk.
  - Open DevTools → Console and read the first error. Most issues will be explained there.
  - Refresh after a few seconds; the IndexedDB setup is asynchronous.
  - Try resetting the local database from the console: `resetDatabase()`; wait for the page to reload.
  - Clear site data: DevTools → Application → Clear storage → “Clear site data”, then reload.

- **404s for icons (e.g., `icons/icon-144x144.png 404`)**
  - Harmless during development; add the PNGs later (see “Adding Icons”).

- **Service Worker won’t update**
  - Hard refresh (Ctrl+F5) or go to DevTools → Application → Service Workers → check “Update on reload”. You can also unregister the old worker and reload.

- **USSD UI doesn’t show**
  - The app will automatically fall back to the web login screen if the USSD markup is missing. You can still log in with the web form.

- **I forgot the credentials**
  - Web: `student1/password123` (Student), `teacher1/teacher123` (Teacher), `admin/admin123` (Teacher)
  - USSD passwords: `password123` (Student), `teacher123` (Teacher), `admin123` (Admin)

- **I want to start fresh**
  - In the browser console, run: `resetDatabase()`.

## Developer Guide (architecture overview)

- **Entry point**: `index.html` (loads `js/database.js`, `js/auth.js`, `js/app.js`)
- **Initialization flow**: On `DOMContentLoaded`, `visionDB.init()` sets up IndexedDB stores and seeds default data; then `authManager.init()` restores a session if present; UI shows either a dashboard (if logged in) or the USSD/web login screen.
- **Core modules**:
  - `js/database.js`: `VisionCollegeDB` (IndexedDB wrapper). Stores: `users`, `notes`, `syllabus`, `grades`, `sessions`, `syncQueue`.
  - `js/auth.js`: `AuthManager` (login, USSD login, logout, session handling) + UI helpers.
  - `js/app.js`: UI controllers (loading dashboards, notes/syllabus/grades, downloads, service worker registration).

### Data model (IndexedDB stores)
- `users` (id PK, `username` unique, `role` index)
- `sessions` (single key `current_session` with `userId`, `role`, `name`, timestamps)
- `notes` (auto id, indexes: `subject`, `teacherId`, `dateCreated`)
- `syllabus` (auto id, indexes: `subject`, `teacherId`, `dateCreated`)
- `grades` (auto id, indexes: `studentId`, `subject`, `term`)
- `syncQueue` (queued ops for offline; processed when back online)

### Useful debug helpers
- From console: `resetDatabase()` to drop and recreate local data
- From console: `showUsers()` to list all users in the database

### Where to add features
- Add new UI: edit `index.html` + styles in `css/styles.css`
- Add logic/state: `js/app.js` (UI flows) and `js/database.js` (data functions)
- Add auth rules: `js/auth.js`
